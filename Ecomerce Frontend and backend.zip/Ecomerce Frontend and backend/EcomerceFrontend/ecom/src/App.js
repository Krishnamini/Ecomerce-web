
import './App.css';
import Footer from './compontes/Footer';
import Header from './compontes/Header';
import Home from './compontes/Home';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom'
import { HelmetProvider } from 'react-helmet-async';
import {ToastContainer} from 'react-toastify'
import ProductDetails from './compontes/Productdetails';
import ProductSearch from './compontes/ProductSearch';
import Login from './compontes/User/Login';
import Forgot from './compontes/User/ForgotPass'
import Register from './compontes/User/Register'
import store from './compontes/store'
import { useEffect } from 'react';
import { Loaduser } from './actons/UserAction';
import Profile from './compontes/User/Profile';
import SecurieUser from './compontes/route/SecurieUser';
import UpdateProfile from './compontes/User/Updateprofile';
import ChangePass from './compontes/User/ChangePass';
import Cart from './compontes/cart/Cart';
import Shipping from './compontes/cart/Shipping';
import ConfirmOder from './compontes/cart/ConfirmOder';
import Payments from './compontes/payment/Payments'

function App() {
  useEffect(()=>{
    store.dispatch(Loaduser)
  })
  
  return (
    <Router>
      <div className="App">
        <HelmetProvider>
          <Header />
          <div className='container'>
          <ToastContainer theme='dark'/>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/search/:keyword' element={<ProductSearch />} />
            <Route path='/product/:id' element={<ProductDetails />} />
            <Route path='/login' element={<Login />} />
            <Route path='/forgot' element={<Forgot />} />
            <Route path='/register' element={<Register />} />
            <Route path='/myprofile' element={<SecurieUser><Profile/></SecurieUser>}/>
            <Route path='/myprofile/update' element={<SecurieUser><UpdateProfile/></SecurieUser>}/>
            <Route path='/myprofile/update/password' element={<SecurieUser><ChangePass/></SecurieUser>}/>
            <Route path='/cartitem' element={<SecurieUser><Cart/></SecurieUser>}/>
            <Route path='/shipping' element={<SecurieUser><Shipping/></SecurieUser>}/>
            <Route path='/order/confirm' element={<SecurieUser><ConfirmOder/></SecurieUser>}/>
            <Route path='/order/payment' element={<SecurieUser><Payments/></SecurieUser>}/>
          </Routes>
          <Footer />
          </div>
          
        </HelmetProvider>

      </div>
    </Router>

  );
}

export default App;
