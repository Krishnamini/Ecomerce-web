import { combineReducers, configureStore } from '@reduxjs/toolkit'
import { thunk } from 'redux-thunk'
import ProductsSlice from '../slice/productsSlice'
import ProductSlice from '../slice/userProuct'
import UserLogin from '../slice/userLogin'
import userCreate from '../slice/userRegister'
import AddCardReducer from '../slice/cartSlice'


const reducer = combineReducers({
    productsstate: ProductsSlice,
    productstate: ProductSlice,
    authstate: UserLogin,
    userRegister: userCreate,
    CartState: AddCardReducer

})

const store = configureStore({
    reducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(thunk),
})

export default store