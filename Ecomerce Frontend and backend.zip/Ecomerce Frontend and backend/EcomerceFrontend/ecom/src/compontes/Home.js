import React, { Fragment, useEffect, useState } from "react";
import Meta from "./Meta";
import { useDispatch, useSelector } from "react-redux";
import { getproduct } from '../actons/Productaction';
import { Audio } from 'react-loader-spinner';
import Product from "./Product";
import { toast, Slide } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Pagination from "react-js-pagination";

export default function Home() {
    const [currentPage, setCurrentPage] = useState(1);


    const dispatch = useDispatch();
    const { products, loading, error, productsCount, itemsPerPage } = useSelector((state) => state.productsstate);
    const handlePageChange = (pageno) => {

        setCurrentPage(pageno);
    };
    useEffect(() => {

        if (error) {
            toast.error(error, {
                position: 'bottom-center',
                transition: Slide,
            });
        }

        dispatch(getproduct(null,null,currentPage));
    }, [error,dispatch, currentPage]);
    console.log('currentpage', currentPage)


   

    return (
        <Fragment>
            <Meta title={'Welcome Home Page'} />
            <h1 id="products_heading" className="mt-5 suse-custom open-sans-custom ">Latest Products</h1>
            {loading ? (
                <div className="text-center mt-5">
                    <Audio
                        visible={true}
                        height="100"
                        width="100"
                        color="#4fa94d"
                        ariaLabel="three-circles-loading"
                        wrapperStyle={{}}
                        wrapperClass=""
                    />
                </div>
            ) : (
                <>
                    <section id="products" className="container mt-5">
                        <div className="row">
                            {products && products.map(product => (
                                <Product key={product._id} product={product} />
                            ))}
                        </div>
                    </section>
                    {/* productcont not 0 to this pagenination waork */}
                    {productsCount > 0 && productsCount > itemsPerPage ?
                        <div className="d-flex justify-content-center mt-5">
                            <Pagination
                                activePage={currentPage}
                                itemsCountPerPage={itemsPerPage}
                                totalItemsCount={productsCount}
                                onChange={handlePageChange}
                                nextPageText={'Next'}
                                prevPageText={'Prev'}
                                firstPageText={'First'}
                                lastPageText={'Last'}
                                itemClass="page-item"
                                linkClass="page-link"
                            />
                        </div> : null}
                </>
            )}
        </Fragment>
    );
}
