import { useEffect, useState } from "react"
import { useLocation, useNavigate } from "react-router-dom"

export default function Search() {
    const navigate = useNavigate()
    const Location = useLocation()
    const [keyword, setkeyword] = useState('')
    const SearchOpsition = (e) => {
        e.preventDefault()
        navigate(`/search/${keyword}`)
    }
    const clearKeyWord = () => {
        setkeyword("")
    }
    useEffect(() => {
        if (Location.pathname === "/") {
            clearKeyWord()
        }
    },[Location])
    return (
        <form onSubmit={SearchOpsition}>
            <div className="input-group">
                <input
                    type="text"
                    id="search_field"
                    className="form-control"
                    placeholder="Enter Product Name ..."
                    onChange={(e) => {setkeyword(e.target.value) }}
                    value={keyword}

                />
                <div className="input-group-append">
                    <button id="search_btn" className="btn">
                        <i className="fa fa-search" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </form>

    )
}