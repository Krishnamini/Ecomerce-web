import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { Audio } from 'react-loader-spinner';

export default function SecureUser({ children }) {
    const { isAuthenticated, loading } = useSelector(state => state.authstate);

    if (loading) {
        return (
            <div className="loading-spinner">
                <Audio
                    visible={true}
                    height="96"
                    width="96"
                    color="grey"
                    strokeWidth="5"
                    animationDuration="0.75"
                    ariaLabel="rotating-lines-loading"
                    wrapperStyle={{}}
                />
            </div>
        );
    }

    if (!isAuthenticated && !loading) {
        return <Navigate to="/login" />;
    }

    if (isAuthenticated) {
        return children;
    }

}
