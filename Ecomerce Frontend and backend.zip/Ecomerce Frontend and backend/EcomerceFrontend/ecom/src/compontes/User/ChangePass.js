import React, { Fragment, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import {UpdatePasswordData } from "../../actons/UserAction"; // Import your action

export default function ChangePass() {
    const [OldPassword, setOldPassword] = useState('');
    const [NewPassword, setNewPassword] = useState('');
    const {error,isUpdate} = useSelector(state => state.authstate);

    const dispatch = useDispatch();

    const changeHandle = (e) => {
        e.preventDefault();
        dispatch(UpdatePasswordData(OldPassword, NewPassword));
    };

    useEffect(() => {
        if (error) {
            toast.error(error, {
                position: "bottom-center"
            });
            return
            // dispatch(clearAuthError());
        }

        if (isUpdate) {
            toast.success('Password changed successfully!', {
                position: "bottom-center"
            });
            // Clear the form fields after success
            setOldPassword('');
            setNewPassword('');
        }
    }, [error, isUpdate]);

    return (
        <Fragment>
            <div className="row wrapper">
                <div className="col-10 col-lg-5">
                    <form onSubmit={changeHandle} className="shadow-lg">
                        <h3 className="mt-2 mb-5">Update Password</h3>
                        <div className="form-group">
                            <label htmlFor="old_password_field">Old Password</label>
                            <input
                                type="password"
                                id="old_password_field"
                                className="form-control"
                                onChange={(e) => setOldPassword(e.target.value)}
                                value={OldPassword}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="new_password_field">New Password</label>
                            <input
                                type="password"
                                id="new_password_field"
                                className="form-control"
                                onChange={(e) => setNewPassword(e.target.value)}
                                value={NewPassword}
                            />
                        </div>

                        <button type="submit" className="btn update-btn btn-block mt-4 mb-3">Update Password</button>
                    </form>
                </div>
            </div>
        </Fragment>
    );
}
