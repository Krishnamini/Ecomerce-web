import { Fragment, useState, useEffect } from "react";
import Meta from "../Meta";
import { clearAuthError, login } from "../../actons/UserAction";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";



export default function Login() {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const dipatch = useDispatch()
    const { error } = useSelector((state) => state.authstate)
    const navigate = useNavigate()
    const isAuthenticated = localStorage.getItem('authToken');

    const Loginsubmit = (e) => {
        e.preventDefault()
        dipatch(login(email, password, navigate))

        // if (error) {
        //     toast.error(error,{
        //         position: 'bottom-center'
        //     })
        //     return
        // }
        // else{
        //     toast.success("Welcome Guys",{
        //         position: 'bottom-center'
        //     })


        // }
    }
    useEffect(() => {
        if (isAuthenticated) {
            navigate('/');
        } else if (error) {
            toast.error(error, {
                position: 'bottom-center',
            });
        }
        dipatch(clearAuthError())
    }, [isAuthenticated, error, navigate,dipatch]);


    return (
        <Fragment>
            <Meta title={'Welcome Login Page'} />
            <div className="row wrapper">
                <div className="col-10 col-lg-5">
                    <form onSubmit={Loginsubmit} className="shadow-lg">
                        <h1 className="mb-3">Login</h1>
                        <div className="form-group">
                            <label htmlFor="email_field">Email</label>
                            <input
                                type="email"
                                id="email_field"
                                className="form-control"
                                onChange={e => setEmail(e.target.value)}
                                value={email}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="password_field">Password</label>
                            <input
                                type="password"
                                id="password_field"
                                className="form-control"
                                onChange={e => setPassword(e.target.value)}
                                value={password}
                            />
                        </div>

                        <Link to={'/forgot'} className="float-right mb-4">Forgot Password?</Link>

                        <button
                            id="login_button"
                            type="submit"
                            className="btn btn-block py-3"
                        >
                            LOGIN
                        </button>

                        <Link to={'/register'}>New User?</Link>
                    </form>
                </div>
            </div>
        </Fragment>

    )
}