import React, { useState ,useEffect} from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { forgotPassword } from '../../actons/UserAction'; // Ensure the path is correct
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import {Link} from 'react-router-dom'
import Meta from '../Meta'; // Assuming you have a Meta component for setting the page title

const ResetPasswordForm = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { passwordResetError, loading, passwordResetSuccess } = useSelector(state => state.authstate);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (password !== confirmPassword) {
            toast.error('Passwords do not match', { position: 'bottom-center' });
            return;
        }
        if (passwordResetSuccess) {
            toast.success('Password reset successful', { position: 'bottom-center' });
        }
        dispatch(forgotPassword(email, password));
    };

    // Show success or error messages
    useEffect(() => {
        if (passwordResetError) {
            toast.error(passwordResetError, { position: 'bottom-center' });
        }

       
    }, [passwordResetError, passwordResetSuccess, navigate]);

    return (
        <div className="row wrapper">
            <Meta title={'Reset Password'} />
            <div className="col-10 col-lg-5">
                <form onSubmit={handleSubmit} className="shadow-lg">
                    <h1 className="mb-3">Reset Password</h1>
                    
                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input
                            type="email"
                            id="email"
                            className="form-control"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">New Password</label>
                        <input
                            type="password"
                            id="password"
                            className="form-control"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="confirmPassword">Confirm Password</label>
                        <input
                            type="password"
                            id="confirmPassword"
                            className="form-control"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                        />
                    </div>

                    <button
                        type="submit"
                        className="btn btn-block py-3"
                        disabled={loading}
                    >
                        {loading ? 'Submitting...' : 'Reset Password'}
                    </button>

                    <Link to="/login" className="float-right mt-3">Back to Login</Link>
                </form>
            </div>
        </div>
    );
};

export default ResetPasswordForm;
