import { useState,useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { clearAuthError, registerUser } from "../../actons/UserAction"
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

export default function Register() {
    const [userData, setuserData] = useState({
        name: "",
        email: "",
        password: ""
    })
    const isAuthenticated = localStorage.getItem('authToken');
    const dispatch = useDispatch()
    const navigate=useNavigate()
    const { loading,error,success} = useSelector(state => state.userRegister)

    const onChange = (e) => {

            setuserData({ ...userData, [e.target.name]: e.target.value })

    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log({
            name: userData.name,
            email: userData.email,
            password: userData.password,
            // avatar: avatar
        });
        dispatch(registerUser({
            name: userData.name,
            email: userData.email,
            password: userData.password,
            
        }))
        if (success) {
           
            navigate('/')
        }
        

    };
    useEffect(() => {
        if (error) {
            toast.error(error, {
                position: "bottom-center"
            });
        }
        if (isAuthenticated) {
            navigate('/')
        }
        dispatch(clearAuthError());
    }, [error,dispatch,isAuthenticated,navigate]);

    return (
        <div className="row wrapper">
            <div className="col-10 col-lg-5">
                <form onSubmit={handleSubmit} className="shadow-lg" encType='multipart/form-data'>
                    <h1 className="mb-3">Register</h1>

                    <div className="form-group">
                        <label htmlFor="email_field">Name</label>
                        <input type="name" name="name" onChange={onChange} id="name_field" className="form-control" value={userData.name} />
                    </div>

                    <div className="form-group">
                        <label htmlFor="email_field">Email</label>
                        <input
                            type="email"
                            id="email_field"
                            name="email" onChange={onChange}
                            className="form-control"
                            value={userData.email}
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password_field">Password</label>
                        <input
                            type="password"
                            id="password_field"
                            name="password"
                            onChange={onChange}
                            className="form-control"
                            value={userData.password}
                        />
                    </div>

                    

                    <button
                        id="register_button"
                        type="submit"
                        className="btn btn-block py-3"
                        disabled={loading}
                    >
                        REGISTER
                    </button>
                </form>
            </div>
        </div>
    )
}