import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { UpdateProfileData } from "../../actons/UserAction"
import { toast } from "react-toastify"
import { UpdateProfileClear } from "../../slice/userLogin"

export default function UpdateProfile() {
    
    const{error,isUpdate,user}=useSelector(state=>state.authstate)
    const[name,setName]=useState('')
    const[email,setEmail]=useState('')
    const dispatch=useDispatch()

    const submithanlder=(e)=>{
        e.preventDefault();
        dispatch(UpdateProfileData({
            name:name,
            email:email
        }))
    

    }
    useEffect(()=>{
        if (user) {
            setName(user.name)
            setEmail(user.email)
        }
        if (isUpdate) {
            toast.success('Profile Update Success',{
                position:"bottom-center",
                onOpen:()=>dispatch(UpdateProfileClear())

            })
            // navigate('/')
            
            return
        }
        if (error) {
            toast.error(error, {
                position: "bottom-center"
            });
        }

    },[user,isUpdate,error,dispatch])

    return(
        <div className="row wrapper">
        <div className="col-10 col-lg-5">
            <form onSubmit={submithanlder} className="shadow-lg" encType='multipart/form-data'>
                <h1 className="mt-2 mb-5">Update Profile</h1>

                <div className="form-group">
                    <label htmlFor="email_field">Name</label>
                    <input 
                        type="name" 
                        id="name_field" 
                        className="form-control"
                        name='name'
                        onChange={(e)=>setName(e.target.value)}
                        value={name}
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="email_field">Email</label>
                    <input
                        type="email"
                        id="email_field"
                        className="form-control"
                        name='email'
                        onChange={(e)=>setEmail(e.target.value)}
                        value={email}
                    />
                </div>
                <button type="submit" className="btn update-btn btn-block mt-4 mb-3" >Update</button>
            </form>
        </div>
    </div>
    )
    
}