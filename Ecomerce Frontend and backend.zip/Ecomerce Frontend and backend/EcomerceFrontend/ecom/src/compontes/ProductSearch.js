import React, { Fragment, useEffect, useState } from "react";
import Meta from "./Meta";
import { useDispatch, useSelector } from "react-redux";
import { getproduct } from '../actons/Productaction';
import { Audio } from 'react-loader-spinner';
import Product from "./Product";
import { toast, Slide } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import Pagination from "react-js-pagination";
import { useParams } from "react-router-dom";


export default function ProductSearch() {
    // const [currentPage, setCurrentPage] = useState(1);


    const dispatch = useDispatch();
    const { keyword } = useParams()
    const { products, loading, error } = useSelector((state) => state.productsstate);
    const Categories = [
        'Electronics',
        'Mobile Phones',
        'Laptops',
        'Tablets',
        'Computers',
        'Accessories',
        'Headphones',
        'Food',
        'Books',
        'Clothes/Shoes',
        'Beauty/Health',
        'Sports',
        'Outdoor',
        'Home'
    ]
    const [category, setCategory] = useState(null)

    useEffect(() => {
        console.log(keyword);
        if (error) {
            toast.error(error, {
                position: 'bottom-center',
                transition: Slide,
            });
        }

        dispatch(getproduct(keyword, category))
    }, [keyword, error, dispatch, category]);
    console.log('currentpage',)


    // const handlePageChange = (pageno) => {

    //     setCurrentPage(pageno);
    // };

    return (
        <Fragment>
            <Meta title={'Welcome Home Page'} />
            <h1 id="products_heading" className="mt-5">Search Products</h1>
            {loading ? (
                <div className="text-center mt-5">
                    <Audio
                        visible={true}
                        height="96"
                        width="96"
                        color="grey"
                        strokeWidth="5"
                        animationDuration="0.75"
                        ariaLabel="rotating-lines-loading"
                        wrapperStyle={{}}
                        wrapperClass=""
                    />
                </div>
            ) : (
                <>
                    <section id="products" className="container mt-5">
                        <div className="row">
                            <div className="col-6 col-md-3 mb-5 mt-5">
                                {/* Categroy Filter*/}
                                <div>
                                    <h3>Categories</h3>
                                    <ul className="pl-0">
                                        {Categories.map((cat) => (
                                            <li
                                                onClick={() => setCategory(cat)}
                                                style={{ cursor: "pointer", listStyleType: "none" }}
                                                key={cat}
                                            >
                                                {cat}
                                            </li>
                                        ))}

                                    </ul>
                                </div>
                            </div>
                            <div className="col-6 col-md-9">
                                <div className="row">
                                    
                                        {products && products.map(product => (
                                            <Product key={product._id} product={product} />
                                        ))}
                                    

                                </div>
                            </div>
                        </div>
                    </section>

                    {/* productcont not 0 to this pagenination waork */}
                    {/* {productsCount > 0 && productsCount > itemsPerPage ?
                        <div className="d-flex justify-content-center mt-5">
                            <Pagination
                                activePage={currentPage}
                                itemsCountPerPage={itemsPerPage}
                                totalItemsCount={productsCount}
                                onChange={handlePageChange}
                                nextPageText={'Next'}
                                prevPageText={'Prev'}
                                firstPageText={'First'}
                                lastPageText={'Last'}
                                itemClass="page-item"
                                linkClass="page-link"
                            />
                        </div> : null} */}
                </>
            )}
        </Fragment>
    );
}
