import React, { Fragment, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Meta from "./Meta";
import { useParams } from "react-router-dom";
import { Audio } from 'react-loader-spinner';
import { getproduct } from "../actons/userProductaction";
import { Carousel } from 'react-bootstrap';
import { addCartItems } from "../actons/CartAction";

export default function ProductDetails() {
    const dispatch = useDispatch();
    const { id } = useParams();
    const { products, loading, error } = useSelector((state) => state.productstate);
    const [quantity, setquantity] = useState(1)

    useEffect(() => {
        dispatch(getproduct(id));
    }, [dispatch, id]);

    const quantityincreas = () => {
        const count = document.querySelector('.count')
        if (products.stock === 0 || count.valueAsNumber >= products.stock) return;
        const qyt = count.valueAsNumber + 1
        setquantity(qyt)

    }
    const quantitydecrease = () => {
        const count = document.querySelector('.count')
        if (count.valueAsNumber === 1) return;
        const qyt = count.valueAsNumber - 1
        setquantity(qyt)

    }

    // Display the loader while data is loading
    if (loading) {
        return (
            <div className="loader-container d-flex justify-content-center align-items-center">
                <Audio
                    visible={true}
                    height="80"
                    width="80"
                    color="#4fa94d"
                    ariaLabel="audio-loading"
                    wrapperStyle={{}}
                    wrapperClass="audio-wrapper"
                />
                <p className="loader-text">Loading product details...</p>
            </div>
        );
    }

    // Handle error case
    if (error) {
        return <div className="alert alert-danger">Error: {error}</div>;
    }

    // Handle case when product data is not available
    if (!products) {
        return <div>No product data available</div>;
    }

    return (
        <Fragment>
            <Meta title={products.name} />
            <div className="row justify-content-around">
                <div className="col-12 col-lg-5 img-fluid" id="product_image">
                    <Carousel pause="hover">
                        {products.image && products.image.map((image) => (
                            <Carousel.Item key={image._id}>
                                <img
                                    className="d-block w-100"
                                    src={image.image}
                                    alt={products.name}
                                    height="500"
                                    width="500"
                                />
                            </Carousel.Item>
                        ))}
                    </Carousel>
                </div>

                <div className="col-12 col-lg-5 mt-5">
                    <h3 className="suse-custom open-sans-custom">{products.name}</h3>
                    <p className="suse-custom open-sans-custom" id="product_id">Product # {products._id}</p>

                    <hr />

                    <div className="rating-outer">
                        <div
                            className="rating-inner"
                            style={{ width: `${(products.ratings / 5) * 100}%` }}
                        ></div>
                    </div>
                    <span id="no_of_reviews">({products.numOfReviews} Reviews)</span>

                    <hr />

                    <p id="product_price" className="suse-custom open-sans-custom">${products.price}</p>
                    <div className="stockCounter d-inline">
                        <span onClick={quantitydecrease} className="btn btn-danger minus">-</span>
                        <input type="number" className="form-control count d-inline mx-2" value={quantity} readOnly />
                        <span onClick={quantityincreas} className="btn btn-primary plus">+</span>
                    </div>
                    <button type="button" id="cart_btn" disabled={products.stock === 0 ? true : false} className="btn btn-primary d-inline ml-4 suse-custom open-sans-custom"  onClick={() => dispatch(addCartItems(products._id, quantity))}>Add to Cart</button>

                    <hr />

                    <p className="suse-custom open-sans-custom">Status: <span id="stock_status" style={{ color: products.stock > 0 ? "green" : "red" }}>
                        {products.stock > 0 ? 'In Stock' : 'Out of Stock'}
                    </span></p>

                    <hr />

                    <h4 className="mt-2 suse-custom open-sans-custom">Description:</h4>
                    <p>{products.description}</p>

                    <hr />
                    <p id="product_seller mb-3 suse-custom open-sans-custom">Sold by: <strong>{products.seller}</strong></p>

                    <button id="review_btn" type="button" className="btn btn-primary mt-4 suse-custom open-sans-custom" data-toggle="modal" data-target="#ratingModal">
                        Submit Your Review
                    </button>

                    <div className="row mt-2 mb-5">
                        <div className="rating w-50">
                            <div className="modal fade" id="ratingModal" tabIndex="-1" role="dialog" aria-labelledby="ratingModalLabel" aria-hidden="true">
                                <div className="modal-dialog" role="document">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <h5 className="modal-title" id="ratingModalLabel">Submit Review</h5>
                                            <button type="button" className="close suse-custom open-sans-custom" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div className="modal-body">
                                            <ul className="stars">
                                                <li className="star"><i className="fa fa-star"></i></li>
                                                <li className="star"><i className="fa fa-star"></i></li>
                                                <li className="star"><i className="fa fa-star"></i></li>
                                                <li className="star"><i className="fa fa-star"></i></li>
                                                <li className="star"><i className="fa fa-star"></i></li>
                                            </ul>
                                            <textarea name="review" id="review" className="form-control mt-3"></textarea>
                                            <button className="btn my-3 float-right review-btn px-4 text-white" data-dismiss="modal" aria-label="Close">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Fragment>
    );
}
