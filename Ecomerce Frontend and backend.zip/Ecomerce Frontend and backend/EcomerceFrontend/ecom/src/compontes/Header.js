// Header.js

import React from "react";
import Search from "./Search";
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from "react-redux";
import { Dropdown } from "react-bootstrap";
import { logoutuser } from "../actons/UserAction";

export default function Header() {
  const { isAuthenticated, user } = useSelector(state => state.authstate);
  const {items:Cartitem}=useSelector(state=>state.CartState)
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const Logout = () => {
    dispatch(logoutuser(navigate));
  };
 

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light bg-light1 ">
  <div className="container-fluid">
    <Link to="/" className="navbar-brand">
      <img src="/image/products/smartShop.jpeg" alt="Shop Logo" className="img-fluid" />
    </Link>

    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>

    <div className="collapse navbar-collapse" id="navbarNav">
      <div className="row w-100">
        <div className="col-12 col-md-6 mt-2 mt-md-0">
          <Search />
        </div>

        <div className="col-12 col-md-6 mt-4 mt-md-0 d-flex justify-content-center align-items-center">
          <div className="d-flex align-items-center">
            <img src="/image/products/userInfo.jpeg" alt="" className="img-fluid" style={{ maxHeight: '50px' }} />

            {isAuthenticated ? (
              <Dropdown className="d-inline mx-3">
                {user && (
                  <>
                    <Dropdown.Toggle variant="secondary" id="dropdown-basic">
                      User: {user.name}
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                      <Dropdown.Item onClick={() => navigate('/myprofile')}>Profile</Dropdown.Item>
                      <Dropdown.Item onClick={Logout}>Logout</Dropdown.Item>
                    </Dropdown.Menu>
                  </>
                )}
              </Dropdown>
            ) : (
              <Link to={'/login'} className="btn btn-primary mx-3" id="login_btn">Login</Link>
            )}

            <Link to={'/cartitem'} className="d-inline">
              <span id="cart" className="mr-2">Cart</span>
              <span className="badge badge-primary" id="cart_count">{Cartitem.length}</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  </div>
</nav>

  );
}
