import { Fragment } from "react";
import { useDispatch, useSelector } from "react-redux";
import { decreaseCartitemQty, increaseCartitemQty, removecartitem } from "../../slice/cartSlice";
import { useNavigate } from "react-router-dom";

export default function Cart() {
    const { items } = useSelector(state => state.CartState);
    const dispatch = useDispatch()
    const navigate = useNavigate()
    console.log('CartItems', items);
    if (items.length === 0) {
        localStorage.removeItem('cartItems')
    }
    const calculateTotal = (items) => {
        let total = 0;
        for (let i = 0; i < items.length; i++) {
            total += items[i].quantity * items[i].price;
        }
        return total;
    };

    const Checkout = () => {
        var auth = localStorage.getItem('authToken')
        if (auth) {
            navigate('/shipping')
        }
        else {
            navigate('/login?redirect=shipping')
        }
    }
    const handleRemoveClick = (product) => {
        dispatch(removecartitem(product));
        var localdataremove=JSON.parse(localStorage.getItem('cartItems'))

        if (product===localdataremove.product) {
            alert()
            
        }
    };


    return (
        <Fragment>
            <h2 className="mt-5">Your Cart: <b>{items.length} {items.length === 1 ? "item" : "items"}</b></h2>

            {items.length === 0 ? (
                <div className="alert alert-info mt-5 text-center">
                    Your cart is empty.
                </div>
            ) : (
                <div className="row d-flex justify-content-between">
                <div className="col-12 col-lg-8" >
                    <hr />
                    {items.map((carts, index) => (
                        <div key={index} className="cart-item shadow-sm p-3 mb-4 bg-light rounded">
                            <div className="row">
                                <div className="col-4 col-lg-3">
                                    <img src={carts.image} alt="Product" height="90" width="115" />
                                </div>
                                <div className="col-5 col-lg-3 suse-custom open-sans-custom">
                                    <p>{carts.name}</p>
                                </div>
                                <div className="col-4 col-lg-2 mt-4 mt-lg-0 suse-custom open-sans-custom">
                                    <p id="card_item_price">${carts.price}</p>
                                </div>
                                <div className="col-4 col-lg-3 mt-4 mt-lg-0">
                                    <div className="stockCounter d-inline ">
                                        <span className="btn btn-danger minus" onClick={() => dispatch(decreaseCartitemQty(carts.product))}>-</span>
                                        <input type="number" className="form-control count d-inline" value={carts.quantity} readOnly />
                                        <span className="btn btn-primary plus" onClick={() => dispatch(increaseCartitemQty(carts.product))}>+</span>
                                    </div>
                                </div>
                                <div className="col-4 col-lg-1 mt-4 mt-lg-0">
                                    <i id="delete_cart_item" onClick={() => handleRemoveClick(carts.product)} className="fa fa-trash btn btn-danger"></i>
                                </div>
                            </div>
                        </div>
                    ))}
                    <hr />
                </div>
            
                <div className="col-12 col-lg-3 my-4 ">
                    <div id="order_summary">
                        <h4>Order Summary</h4>
                        <hr />
                        <p>Subtotal: <span className="order-summary-values">{items.length} {items.length === 1 ? "Unit" : "Units"}</span></p>
                        <p>Est. total: <span className="order-summary-values">{calculateTotal(items)}</span></p>
                        <hr />
                        <button id="checkout_btn" className="btn btn-primary btn-block" onClick={Checkout}>Check out</button>
                    </div>
                </div>
            </div>
            
            )}
        </Fragment>
    );
}
