import React from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';

const RazorpayPayment = () => {
    // Use useSelector at the top level of your component
    const { shippingInfo } = useSelector(state => state.CartState);
    const { user } = useSelector(state => state.authstate)

    const handlePayment = async () => {
        try {
            // Call your backend to create a Razorpay order
            const { data } = await axios.post('/api/v1/payment/process', {
                amount: 100000, // Amount in INR (e.g., ₹10.00)
                currency: 'INR',
                shipping: {
                    name: 'Krishna Kumar',
                    phone: shippingInfo.phoneNumber,
                    address: { city: shippingInfo.address }
                }
            });

            // Get the key_id and order from the backend
            const { key_id, order } = data;

            // Initialize Razorpay options
            const options = {
                key: key_id, // Razorpay API Key ID from the server
                amount: order.amount, // Amount in paise (1000 paise = ₹10.00)
                currency: order.currency,
                name: 'SHOPIE',
                description: 'Test Transaction',
                order_id: order.id, // Razorpay order ID
                handler: async function (response) {
                    // Handle successful payment
                    const paymentData = {
                        order_id: response.razorpay_order_id,
                        payment_id: response.razorpay_payment_id,
                        signature: response.razorpay_signature
                    };

                    console.log('Payment Success:', paymentData);

                    // You can send this to the backend to verify the payment
                    await axios.post('/api/v1/payment/process', paymentData);
                },
                prefill: {
                    name: user.name,
                    email: user.email,
                    contact: shippingInfo.phoneNumber
                },
                notes: {
                    address: shippingInfo.address
                },
                theme: {
                    color: '#3399cc'
                }
            };

            // Initialize Razorpay instance and open checkout
            const razorpay = new window.Razorpay(options);
            razorpay.open();

        } catch (error) {
            console.error('Payment error:', error);
        }
    };

    return (
        <div className="payment-container text-center">
            <h1 className="payment-title suse-custom open-sans-custom">Razorpay Payment</h1>
            <button className="btn btn-primary btn-lg payment-button suse-custom open-sans-custom" onClick={handlePayment}>
                Pay with Razorpay
            </button>
        </div>
    );
};


export default RazorpayPayment;
