import { createSlice } from '@reduxjs/toolkit';


const productSlice=createSlice({
    name:'products',
    initialState:{
        loading:false,
        products:{}
    },
    reducers:{
        productRequest(state,action){
            return{
                loading:true
            }
        },
        productSuccess(state,action){
            return{
                loading:false,
                products:action.payload.product
            }
        },
        productFailure(state,action){
            return{
                loading:false,
                error:action.payload
            }
        }
    }
})

const {actions,reducer}=productSlice
export const { productRequest, productSuccess, productFailure } = actions;
export default reducer;
