import { createSlice } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';


const CartSlice = createSlice({
    name: 'cart',
    initialState: {
        items: localStorage.getItem('cartItems') ? JSON.parse(localStorage.getItem('cartItems')) : [],
        loading: false,
        shippingInfo:localStorage.getItem('shippingInfo') ? JSON.parse(localStorage.getItem('shippingInfo')) :{},
       

    },
    reducers: {
        AddcartItemRequest(state, action) {
            return {
                ...state,
                loading: true
            }
        },
        AddcartItemSuccess(state, action) {
            const item = action.payload
            const exititem = state.items.find(i => i.product === item.product)
            if (exititem) {
                toast.error('Aleready this Product Add please go to cart page',{
                    position:'top-center'
                })
                state = {
                    ...state,
                    loading: false,
                }

            }
            else {
                toast.success('Product Add ',{
                    position:'top-center'
                })

                state = {
                    items: [...state.items, item],
                    loading: false
                }
                localStorage.setItem('cartItems', JSON.stringify(state.items))
            }
            return state
        },
        increaseCartitemQty(state, action) {
            state.items = state.items.map(item => {
                // Check if the item's stock is 0 or if the current quantity is already at the stock limit
                if (item.product === action.payload) {
                    if (item.stock === 0 || item.quantity >= item.stock) {
                        toast.error(`Only Stock Availble ${item.stock}`, {
                            position:'bottom-center'
                        })
                        return item; // If stock is 0 or quantity exceeds stock, don't update
                    }

                    // If the stock allows, increase the quantity
                    item.quantity += 1;
                }
                return item;
            });

            // Update localStorage with the new state
            localStorage.setItem('cartItems', JSON.stringify(state.items));
        },

        decreaseCartitemQty(state, action) {
            state.items = state.items.map(item => {
                if (item.product === action.payload) {
                    // Ensure that the quantity doesn't go below 1
                    if (item.quantity > 1) {
                        item.quantity -= 1;
                    }
                }
                return item;
            });

            // Update localStorage with the new state
            localStorage.setItem('cartItems', JSON.stringify(state.items));
        }
        ,
        removecartitem(state, action) {
            // Find the index of the item to be removed
            const index = state.items.findIndex(item => item.product === action.payload);
        
            // If the item exists, remove it using splice
            if (index !== -1) {
                state.items.splice(index, 1);
            }
        
            // Update localStorage with the new items array after removal
            localStorage.setItem('cartItems', JSON.stringify(state.items));
        
            // No need to return anything; Immer takes care of it
        },
        
        shipingCart(state,action){
            localStorage.setItem('shippingInfo',JSON.stringify(action.payload) )
            return{
                ...state,
                shippingInfo:action.payload

            }

        }
    }
})

const { actions, reducer } = CartSlice
export const { AddcartItemRequest, AddcartItemSuccess, increaseCartitemQty, decreaseCartitemQty, removecartitem,shipingCart} = actions;
export default reducer;
