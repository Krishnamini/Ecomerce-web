import { createSlice } from '@reduxjs/toolkit';

const userCreate = createSlice({
    name: "UserRegister",
    initialState: {
        loading: false,

    },
    reducers: {
        UserregisterRequest(state, action) {
            return {
                ...state,
                loading: true
            }
        },
        UserregisterSuccess(state, action) {
            return {
                loading: false,
                success:true,
                user: action.payload.user
            }
        },
        UserregisterFailure(state, action) {
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        }
    }
})
const { actions, reducer } = userCreate
export const { UserregisterRequest, UserregisterSuccess, UserregisterFailure } = actions;
export default reducer;
