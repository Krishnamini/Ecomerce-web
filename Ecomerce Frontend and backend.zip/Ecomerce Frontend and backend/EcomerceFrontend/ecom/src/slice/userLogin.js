import { createSlice } from '@reduxjs/toolkit';


const UserLogin = createSlice({
    name: 'auth',
    initialState: {
        loading: true,
        isAuthenticated: false
    },
    reducers: {
        UserLoginRequest(state, action) {
            return {
                ...state,
                loading: true
            }
        },
        UserLoginSuccess(state, action) {
            return {
                loading: false,
                isAuthenticated: true,
                success: true,
                user: action.payload.user

            }
        },
        userLoginFailure(state, action) {
            return {
                loading: false,
                isAuthenticated: false,
                error: action.payload
            }
        },
        clearError(state, action) {
            return {
                loading: false,
                error: null
            }
        },
        forgotPasswordRequest(state, action) {
            return {
                ...state,
                passwordResetRequest: true,
                passwordResetSuccess: false,

            }
        },
        forgotPasswordSuccess(state, action) {
            return {
                ...state,
                passwordResetRequest: false,
                passwordResetSuccess: true,
                passwordResetError: false,
            };
        },
        forgotPasswordFailure(state, action) {
            return {
                ...state,
                passwordResetRequest: false,
                passwordResetSuccess: false,
                passwordResetError: action.payload,
            };
        },


        //Load user data
        loaduserRequesr(state, action) {
            return {
                ...state,
                isAuthenticated: false,
                loading: true


            }
        },
        loaduserSucess(state, action) {
            return {
                ...state,
                isAuthenticated: true,
                loading: false,
                user: action.payload.user

            }
        },

        loaduserFaileure(state, action) {
            return {
                ...state,
                isAuthenticated: false,
                loading: false,
                // error: action.payload

            }

        },


        //logout
        logoutRequest(state, action) {
            return {
                ...state,
                isAuthenticated: false,
                loading: true


            }
        },
        logoutSucess(state, action) {
            return {
                ...state,
                isAuthenticated: true,
                loading: false

            }
        },

        logoutFaileure(state, action) {
            return {
                ...state,
                isAuthenticated: false,
                loading: false,
                error:action.payload

            }

        },

        //update Profile
        UpdateProfileRequest(state, action) {
            return {
                ...state,
                loading: true,
                isUpdate:false
            }
        },
        UpdateProfileSuccess(state, action) {
            return {
                ...state,
                loading: false,
                isUpdate:true,
                user: action.payload.user
            }
        },
        UpdateProfileClear(state, action) {
            return {
                ...state,
                isUpdate:false,
            }
        },
        UpdateProfileFailure(state, action) {
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        },

        //ChangePassword
        UpdatePasswordRequest(state, action) {
            return {
                ...state,
                loading: true,
                isUpdate:false
            }
        },
        UpdatePasswordsuccess(state, action) {
            return {
                ...state,
                loading: false,
                isUpdate:true,
               
            }
        },
        UpdatePasswordFailure(state, action) {
            return {
                ...state,
                loading: false,
                error: action.payload
            }
        }



    }
})

const { actions, reducer } = UserLogin
export const { UserLoginRequest, UserLoginSuccess, userLoginFailure, clearError, forgotPasswordRequest,
    forgotPasswordSuccess,
    forgotPasswordFailure ,
    loaduserRequesr,
    loaduserSucess,
    loaduserFaileure,
    logoutRequest,
    logoutSucess,
    logoutFaileure,
    //update profile
    UpdateProfileSuccess,
    UpdateProfileRequest,
    UpdateProfileFailure,
    UpdateProfileClear,
    //ChangePassword
    UpdatePasswordRequest,
    UpdatePasswordsuccess,
    UpdatePasswordFailure
} = actions;
export default reducer