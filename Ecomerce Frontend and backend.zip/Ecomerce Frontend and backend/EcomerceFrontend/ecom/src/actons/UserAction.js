import axios from 'axios';
import {
    userLoginFailure,
    UserLoginRequest,
    UserLoginSuccess,
    forgotPasswordRequest,
    forgotPasswordSuccess,
    forgotPasswordFailure,
    clearError,
    loaduserRequesr,
    loaduserSucess,
    loaduserFaileure,
    logoutRequest,
    logoutSucess,
    logoutFaileure,
    UpdateProfileRequest,
    UpdateProfileSuccess,
    UpdateProfileFailure,
    UpdatePasswordRequest,
    UpdatePasswordFailure,
    UpdatePasswordsuccess
} from '../slice/userLogin';
import { UserregisterRequest, UserregisterSuccess, UserregisterFailure } from '../slice/userRegister'

export const login = (email, password, navigate) => async (dispatch) => {

    try {
        dispatch(UserLoginRequest());

        const { data } = await axios.post(`/api/v1/userlogin`, { email, password });
        localStorage.setItem('authToken', data.token);

        dispatch(UserLoginSuccess(data));
        navigate('/')
        console.log(data);

    } catch (error) {

        console.log('error', error);
        // Check if error.response is defined
        const errorMessage = error.response?.data?.message || 'Something went wrong';
        // console.log(error.response.data.statusCode);
        dispatch(userLoginFailure(errorMessage));
    }
};
//clear error
export const clearAuthError = () => (dispatch) => {
    dispatch(clearError());
};
///Forgot Password
export const forgotPassword = (email, password) => async (dispatch) => {
    try {
        dispatch(forgotPasswordRequest())
        const { data } = await axios.post(`/api/v1/password/resetpass`, { email, password })
        dispatch(forgotPasswordSuccess(data))


    }
    catch (error) {
        const errorMessage = error.response?.data?.message
        dispatch(forgotPasswordFailure(errorMessage))
    }


}
// userRegister
export const registerUser = (userData) => async (dispatch) => {
    console.log("userData", userData);
    try {
        dispatch(UserregisterRequest());
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }

        const { data } = await axios.post(`/api/v1/usercraete`, userData, config);

        dispatch(UserregisterSuccess(data));
    } catch (error) {
        console.log(error);
        dispatch(UserregisterFailure(error.response?.data?.message));
    }
}

//load user data
export const Loaduser = async (dispatch) => {
    try {
        dispatch(loaduserRequesr());
        const { data } = await axios.get(`/api/v1/myprofile`);

        dispatch(loaduserSucess(data));
    } catch (error) {
        console.log(error);
        dispatch(loaduserFaileure(error.response?.data?.message));
    }
}

//logout
export const logoutuser = (navigate) => async (dispatch) => {
    try {
        dispatch(logoutRequest());
        await axios.get(`/api/v1/userlogout`);
        localStorage.removeItem('authToken');
        dispatch(logoutSucess());
        navigate('/login'); // Redirect to login after logout
    } catch (error) {
        dispatch(logoutFaileure(error.message));
    }
};


//Update Profile
export const UpdateProfileData = (userData) => async (dispatch) => {
    console.log("userData", userData);
    try {
        dispatch(UpdateProfileRequest());
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }

        const { data } = await axios.put(`/api/v1/userUpdate`, userData, config);

        dispatch(UpdateProfileSuccess(data));
    } catch (error) {
        console.log(error);
        dispatch(UpdateProfileFailure(error.response?.data?.message));
    }
}

//Change Password

export const UpdatePasswordData = (oldPassword, newPassword)=> async (dispatch) => {
    console.log("userData",);
    try {
        dispatch(UpdatePasswordRequest());

        await axios.put(`/api/v1/Changepassword`, {
            oldpassword: oldPassword, // Make sure the key name matches what your backend expects
            password: newPassword // The new password is passed as 'password'
        });

        dispatch(UpdatePasswordsuccess());
    } catch (error) {
        console.log(error);
        dispatch(UpdatePasswordFailure(error.response?.data?.message));
    }
}

