// import axios from "axios"
// import { PaymentFailure, PaymentRequest, PaymentSuccess } from "../slice/paymentSlice"


// export const Paymentamount =(paymentData)=> async (dispatch) => {
//     try {
//         dispatch(PaymentRequest())
//         const { data } = await axios.post('/api/v1/payment/razorpay', paymentData)
//         dispatch(PaymentSuccess(data))
        
//     } catch (error) {
//         dispatch(PaymentFailure(error.response && error.response.data.message ? error.response.data.message : error.message));
        
//     }


// }