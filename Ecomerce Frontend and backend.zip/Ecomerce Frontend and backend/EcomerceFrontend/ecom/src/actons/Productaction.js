import axios from 'axios';
import { productsFailure, productsRequest, productsSuccess } from '../slice/productsSlice';

export const getproduct = (keyword,category,currentPage) => async (dispatch) => {
    try {
        dispatch(productsRequest());

        // Construct the URL with query parameters
        let link = `/api/v1/product?page=${currentPage}`;
        if (keyword) {
            link += `&keyword=${encodeURIComponent(keyword)}`; // Encode the keyword for safe URL usage
        }
        if (category) {
            link += `&category=${encodeURIComponent(category)}`;
        }

        // Make the API request with the constructed URL
        const { data } = await axios.get(link);
        dispatch(productsSuccess(data));
        console.log(data);
    } catch (err) {
        // Handle errors by dispatching the failure action
        dispatch(productsFailure(err.response ? err.response.data.message : err.message));
    }
};
