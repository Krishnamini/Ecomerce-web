import axios from "axios"
import { AddcartItemRequest, AddcartItemSuccess } from "../slice/cartSlice"

export const addCartItems = (id, quantity) => async (dispatch) => {
   
    try {
        dispatch(AddcartItemRequest())
        const { data } = await axios.get(`/api/v1/product/${id}`)
        console.log('daya', data);

        dispatch(AddcartItemSuccess({
            product: data.product._id,
            name: data.product.name,
            price: data.product.price,
            image: data.product.image[0].image,
            stock: data.product.stock,
            quantity

        }))



    } catch (error) {
        console.log(error);



    }
}
