import axios from 'axios';
import { productRequest, productFailure, productSuccess } from '../slice/userProuct';

export const getproduct = (id) => async (dispatch) => {
    console.log('id',id);
    
    try {
        dispatch(productRequest());
        
        const { data } = await axios.get(`/api/v1/product/${id}`); // Ensure the endpoint is correct
        
        dispatch(productSuccess(data));
        console.log(data);
    } catch (err) {
        console.log(err);
        dispatch(productFailure(err.response ? err.response.data.message : err.message));
    }
};
