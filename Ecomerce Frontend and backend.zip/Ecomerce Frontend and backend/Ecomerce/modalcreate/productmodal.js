const mongoose=require('mongoose')


const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter a product name'],
        trim: true,
        maxLength: [100, 'Product name cannot exceed 100 characters']
    },
    price: { 
        type: Number, 
        required: [true, 'Please enter a price'],
        default: 0.0
    },
    description: {
        type: String,
        required: [true, 'Please enter a description']
    },
    ratings: {
        type: Number, // corrected from String to Number
        default: 0
    },
    image: [
        {
            image: {
                type: String,
                required: true
            }
        }
    ],
    category: {
        type: String,
        required: [true, 'Please enter a category'],
        enum: {
            values: [
                'Electronics',
                'Mobile Phones',
                'Laptops',
                'Tablets',
                'Computers',
                'Accessories',
                'Headphones',
                'Food',
                'Books',
                'Clothes/Shoes', // corrected from Cloths/Shoes to Clothes/Shoes
                'Beauty/Health',
                'Sports',
                'Outdoor',
                'Home'
            ],
            message: 'Please select a valid category'
        }
    },
    seller: {
        type: String,
        required: [true, 'Please select a seller']
    },
    stock: {
        type: Number, // corrected from String to Number
        required: [true, 'Please enter stock'],
        maxLength: [20, 'Product stock cannot exceed 20 items']
    },
    numOfReviews: {
        type: Number, // corrected from String to Number
        default: 0
    },
    reviews: [ // corrected from reviwes to reviews
        {
            user: {
                type:mongoose.Schema.Types.ObjectId //user objct Id
            },
            rating: {
                type: Number, // corrected from String to Number
                required: true
            },
            comment: {
                type: String,
                required: true
            }
        }
    ],
    //new product set to user find
    user:{
        type:mongoose.Schema.Types.ObjectId

    },
    createdAt: { // corrected from createAt to createdAt
        type: Date,
        default: Date.now() // corrected from defalut to default and Date.now() to Date.now
    }
});


const Ecom=mongoose.model('Product',productSchema)
module.exports=Ecom