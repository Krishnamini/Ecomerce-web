const mongoose=require('mongoose')
const vaildator=require('validator')
const jwt=require('jsonwebtoken')
const crypto=require('crypto')
const bcrypt=require('bcrypt')

const userschema=new mongoose.Schema({
    name:{
        type:String,
        required:[true,'please enter name']
    },
    email:{
        type:String,
        required:[true,'please enter email'],
        unique:true,
        validata:[vaildator.isEmail,'please enter email address']
    },
    password:{
        type:String,
        required:[true,'please enter password'],
        select:false
        // maxlength:[6,'please enter cannot exceed 6  characters only accept']
    },
    // avatar:{
    //     type:String,
    //     required:true
    // },
    roole:{
        type:String,
        default:'user'
    },
    resetPasswordToken:String,
    resetPasswordTokenExprire:Date,
    craeteAt:{
        type:Date,
        default:Date.now()
    }
    
})

userschema.methods.getJWtToken=function(){
return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES_TIME
    });
}
userschema.methods.isValidPassword = async function(enteredPassword) {
    return  bcrypt.compare(enteredPassword, this.password);
};
userschema.methods.getreset=function(){
    //genetate token crypto
   const token= crypto.randomBytes(10).toString('hex')
   //hash and set to reasetpasswordtoken
   this.resetPasswordToken=crypto.createHash('sha256').update(token).digest('hex')
   //set token expire time
   this.resetPasswordTokenExprire=Date.now()+30*60*1000
   
   return token

}
const UserModal=mongoose.model('UserDealis',userschema)
module.exports=UserModal 