const mongoose = require('mongoose')

const connectdatabase = () => {
    mongoose.connect("mongodb://127.0.0.1:27017/Ecomerce").then((data) => {
        console.log("database connect");
    })
}

module.exports=connectdatabase