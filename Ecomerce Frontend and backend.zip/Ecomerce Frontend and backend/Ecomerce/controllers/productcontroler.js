const product1 = require('../modalcreate/productmodal')
const ErrorHandler = require('../utils/ErrorHandle');
const Catch = require('../middlewere/catch')
const APIFeature = require('../utils/ApiFeature');

//get-product
exports.getproduct = Catch(async (req, res, next) => {
    const itemsPerPage = 5;
    const totalProducts = await product1.countDocuments({});
    const features = new APIFeature(product1.find(), req.query)
        .search()
        .filter()
        .pagination(itemsPerPage);
    // return next(new  ErrorHandler("unbale to product",400))
    const products = await features.query;
    res.status(200).json({
        success: true,
        count: totalProducts,
        itemsPerPage,
        products,
    });
});
//create product-/api/v1/product/new
exports.newproduct = Catch(async (req, res, next) => {
    req.body.user = req.user.id
    const product = await product1.create(req.body);
    res.status(200).json({
        success: true,
        product
    })
})


//getsingle id-api/v1/updateproduct/:id
exports.getsingleId = Catch(async (req, res, next) => {

    const product = await product1.findById(req.params.id);
    if (!product) {
        return next(new ErrorHandler('Product not found with this ID', 404));
    }
    await new Promise(res=>setTimeout(res,1000))
    res.status(200).json({
        success: true,
        product
    });
});
//update Id getdata-api/v1/updateproduct/:id
exports.updatedata = async (req, res, next) => {
    let updateproductId = await product1.findById(req.params.id)
    if (!updateproductId) {
        res.status(500).json({
            success: false,
            message: "not Id"
        })
    }
    updateproductId = await product1.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
    })
    res.status(200).json({
        suceess: true,
        updateproductId
    })


}
exports.deleteProduct = async (req, res) => {
    try {
        const product = await product1.findByIdAndDelete(req.params.id);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }
        res.status(200).json({
            success: true,
            message: "Product deleted successfully"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

//Reviews :user Rivewes create

exports.userRiewesCreate = Catch(async (req, res, next) => {
    const { productId, rating, comment } = req.body

    const rivew = ({
        user: req.user.id,
        rating,
        comment
    })
    //alerady reviwes to error msg send
    const product = await product1.findById(productId)
    const isreviwes = product.reviews.find(riview => {
        return riview.user.toString() === req.user.id.toString()
    })
    if (isreviwes) {
        product.reviews.forEach(data => {
            if (data.user.toString() === req.user.id.toString()) {
                data.rating = rating
                data.comment = comment
            }
        })

    }
    else {
        product.reviews.push(rivew)
        product.numOfReviews = product.reviews.length
    }
    //find the average of the product reviews
    product.ratings = product.reviews.reduce((acc, review) => {
        return review.rating + acc;
    }, 0) / product.reviews.length
    product.ratings = isNaN(product.ratings) ? 0 : product.ratings;
    // Save the updated product with validateBeforeSave option
    await product.save({ validateBeforeSave: false })

    res.status(200).json({
        success: true,
        message: 'Review added/updated successfully',
    });
})

//Get Rivews --/api/v1/product/reviewsfind?id={productid}
exports.userRiewesFind = Catch(async (req, res, next) => {
    const product=await product1.findById(req.query.id)
    res.status(200).json({
        success: true,
        message: 'Review find',
        reviews:product.reviews
    });

})
//Rivew Deleted
exports.userReviewsDeleted = Catch(async (req, res, next) => {
    const product = await product1.findById(req.query.productId);

    if (!product) {
        return next(new Error('Product not found'));
    }

    const reviews = product.reviews.filter(review => {
        return review._id.toString() !== req.query.id.toString();
    });

    const numOfReviews = reviews.length;

    let ratings = reviews.reduce((acc, review) => {
        return review.rating + acc;
    }, 0) / numOfReviews;

    ratings = isNaN(ratings) ? 0 : ratings;

    await product1.findByIdAndUpdate(req.query.productId, {
        reviews,
        numOfReviews,
        ratings
    });

    res.status(200).json({
        success: true,
    });

});
