const OrderModel = require('../modalcreate/oder');
const productAdmin = require('../modalcreate/productmodal')
const ErrorHandler = require('../utils/ErrorHandle');
const Catch = require('../middlewere/catch')
const APIFeature = require('../utils/ApiFeature');
//new oder create
exports.newoder = Catch(async (req, res, next) => {
    const {
        orderItems,
        shippingInfo,
        itemPrice,
        taxPrice,
        shippingPrice,
        totalPrice,
        paymentInfo
    } = req.body
    // Create a new order
    const oder = await OrderModel.create({
        orderItems,
        shippingInfo,
        itemPrice,
        taxPrice,
        shippingPrice,
        totalPrice,
        paymentInfo,
        paidAt: Date.now(),
        user: req.user.id
    })
    res.status(201).json({
        success: true,
        message: 'Order created successfully',
        oder
    });

})

//Get Sindgle order
exports.GetsingleOrder = Catch(async (req, res, next) => {
    const order = await OrderModel.findById(req.params.id).populate('user', 'name email')
    if (!order) {
        return next(new ErrorHandler(`Order not found this id ${req.params.id}`, 404))
    }
    res.status(200).json({
        success: true,
        message: "Order Finded",
        order
    });
})

//get Loggedin user Orders
exports.GetLoginuserOrders = Catch(async (req, res, next) => {
    const user = await OrderModel.find({ user: req.user.id })
    res.status(200).json({
        success: true,
        message: "Order Finded",
        user,
    });
})

//ADMIN:get all users order
exports.GetallusersOrder = Catch(async (req, res, next) => {
    const user = await OrderModel.find()
    let totalamut = 0
    user.forEach(order => {
        totalamut += order.totalPrice
    })
    res.status(200).json({
        success: true,
        message: "Order Finded",
        totalamut,
        user,
    });
})


//Update Orders /ordwer status-api/v1/order/:id

exports.UpdateOrders = Catch(async (req, res, next) => {
    const order = await OrderModel.findById(req.params.id)

    if (order.orderStatus == "Deleverd") {
        return next(new ErrorHandler("this product aleredy Deleverd"))
    }
    //Updating the product stock of each item
    order.orderItems.forEach(async orderItems => {
        await updatestock(orderItems.product, orderItems.quantity)

    })

    //order Status deliveredAt
    order.orderStatus = req.body.orderStatus
    order.deliveredAt = Date.now()
    await order.save()
    res.status(200).json({
        success: true,
        message: "Order Status Success"
    });
})

async function updatestock(productId, quantity) {
    // Find the product by its ID
    const product = await productAdmin.findById(productId);
    // Check if the product exists
    if (!product) {
        return new ErrorHandler('Product not found', 404); 
    }
    // Update the stock
    product.stock -= quantity;
    // Ensure stock does not go below zero
    if (product.stock < 0) {
        return new ErrorHandler('Insufficient stock', 400); 
    }
    // Save the updated product document
    await product.save({ validateBeforeSave: false });
}

//Admin:Oeder Delated
exports.Deleted=Catch(async(req,res,next)=>{
    const order = await OrderModel.findByIdAndDelete(req.params.id)

    if(!order){
        return next(new ErrorHandler('Oders Not font',401))
    }
    // await order.remove()
    res.status(200).json({
        success:true,
        message:"Oder Deleted"
    })
})