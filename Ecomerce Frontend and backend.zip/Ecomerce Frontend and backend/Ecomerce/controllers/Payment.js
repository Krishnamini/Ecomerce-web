const Razorpay = require('razorpay');
const Catch = require('../middlewere/catch');
const path=require('path')
const dotenv=require('dotenv')
dotenv.config()
console.log('Test ....',process.env.RAZORPAY_API_KEY)
console.log('api',process.env.RAZORPAY_SECRET_KEY);


// Initialize Razorpay instance with API keys
const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_API_KEY,
    key_secret: process.env.RAZORPAY_SECRET_KEY
});

// Create a new payment order
exports.createRazorpayOrder = Catch(async (req, res, next) => {
    const { amount, currency, shipping, } = req.body;

    // Ensure the amount is in the smallest currency unit (e.g., paise for INR)
    const options = {
        amount: amount, // Amount in paise (100 paise = 1 INR)
        currency: currency || 'INR',
        receipt: `receipt_order_${Date.now()}`, // A unique receipt number
        notes: {
            name: shipping.name,
            phone: shipping.phone,
            address: shipping.address.city
        }
    };

    const order = await razorpay.orders.create(options); // Create Razorpay order

    // Respond with the created order
    res.status(200).json({
        success: true,
        order,
        client_secret:process.env.RAZORPAY_SECRET_KEY
    });
});     
