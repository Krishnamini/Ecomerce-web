const Catch = require('../middlewere/catch')
const bcrypt = require('bcryptjs')
const userDeatils = require('../modalcreate/usermodal')
const jwtgen = require('../utils/jwt')
// const { ErrorHandler } = require('@angular/core')
const ErrorHandler = require('../utils/ErrorHandle');
const sendemail = require('../utils/email');
// const sendemail=require('../utils/email')



exports.UserRigester = Catch(async (req, res, next) => {
    const { name, email, password, avatar } = req.body;

    try {
        // Check if user already exists
        const existingUser = await userDeatils.findOne({ email });
        if (existingUser) {
            return next(new ErrorHandler('Email is already registered', 400));
        }

        // Hash the password
        const hashPassword = await bcrypt.hash(password, 10);

        // Create new user
        const user = await userDeatils.create({
            name,
            email,
            password: hashPassword,
            // avatar,
        });

        // Generate JWT token
        const token = user.getJWtToken();

        res.status(200).json({
            success: true,
            message: 'User registered successfully',
            user,
            token
        });
    } catch (error) {
        // Handle other errors, including duplicate key errors
        if (error.code === 11000) {
            return next(new ErrorHandler('Duplicate key error: Email already exists', 400));
        }

        return next(new ErrorHandler(error.message, 500));
    }

})
exports.userDeatilsId = Catch(async (req, res, next) => {
    const singleid = await userDeatils.findById(req.params.id);
    if (!singleid) {
        return next(new ErrorHandler('Product not found with this ID', 404));
    }
    res.status(200).json({
        success: true,
        singleid
    });
});
//userlogin
exports.UserLogin = Catch(async (req, res, next) => {
    const { email, password } = req.body
    const user = await userDeatils.findOne({ email }).select('+password')
    if (!email || !password) {
        return next(new ErrorHandler('please enter email and password', 404))
    }
    if (!user) {
        return next(new ErrorHandler("Invaild email or password", 404))
    }
    const userpassword = await bcrypt.compare(password, user.password)
    if (!userpassword) {
        return next(new ErrorHandler("Invaild email or password", 404))
    }
    const token = user.getJWtToken()
    const opsition = {
        expires: new Date(Date.now() + process.env.COOKIE_EXPIRES_TIME * 24 * 60 * 60 * 1000),
        //only http request and no access javascript
        httpOnly: true,
    }
    res.status(200).cookie('token', token, opsition).json({
        success: true,
        token,
        user
    })
})
//forgot password
// exports.forgot = Catch(async (req, res, next) => {
//     const user = await userDeatils.findOne({ email: req.body.email })
//     if (!user) {
//         return next(new ErrorHandler('inVaild Email'))

//     }
//     const resettoken = user.getreset()
//     user.save({ validateBeforeSave: false })


//     const reseturl = `${req.protocol}://${req.get('host')}/api/v1/password/reset/${resettoken}`
//     const message = `Your password reset url is as  follows \n\n${reseturl}\n\n if you not requested this email,
//     then ignore it`
//     try {
//         sendemail({
//             email: user.email,
//             subject: "krish cart password recovery",
//             message
//         })
//         res.status(200).json({
//             success: true,
//             message: `email send to ${user.email}`
//         })

//     } catch (err) {
//         user.resetPasswordToken = undefined
//         user.resetPasswordTokenExprire = undefined
//         await user.save({ validateBeforeSave: false })
//         return next(new ErrorHandler(err.message), 500)
//     }

// })
exports.forgot = Catch(async (req, res, next) => {
    const { email, password } = req.body
    try {
        const user = await userDeatils.findOne({ email })
        if (!user) {
            return next(new ErrorHandler("Email Not find"))
        }
        const hashpassword = await bcrypt.hash(password, 10)
        user.password = hashpassword
        await user.save()
        res.status(200).json({
            message: "User Password Reset"
        })

    } catch (error) {
        res.status(500).json({
            message: error
        })
    }
})

//crating logout controllers
exports.userlogout = (req, res, next) => {
    res.cookie('token', null, {
        expires: new Date(Date.now()),
        httpOnly: true

    })
    res.status(200).json({
        sucess: true,
        message: 'Your Account Logout'
    })
}
//get user profile
exports.getuser = Catch(async (req, res, next) => {
    const user = await userDeatils.findById(req.user.id)
    res.status(200).json({
        success: true,
        user
    })

})

//change password
exports.changepassword = Catch(async (req, res, next) => {
    const user = await userDeatils.findById(req.user.id).select('+password')
    //cheack Old password
    if (!await user.isValidPassword(req.body.oldpassword)) {
        return next(new ErrorHandler('old password incorrct', 401))
    }
    //assiging new password
    const hashpassword = await bcrypt.hash(req.body.password, 10)
    user.password = hashpassword
    await user.save()
    res.status(200).json({
        success: true
    })
})
//UPDATE PROFlE
exports.userUpdate = Catch(async (req, res, next) => {

    const userupdate = {
        name: req.body.name,
        email: req.body.email
    }
    const user = await userDeatils.findByIdAndUpdate(req.user.id, userupdate, {
        new: true,
        runValidators: true
    })
    console.log(req.user.id);

    res.status(200).json({
        success: true,
        // message:"user Details Update",
        user
    })

})

//Admin:get all users
exports.getalluser = Catch(async (req, res, next) => {
    const user = await userDeatils.find()
    res.status(200).json({
        sucess: true,
        user
    })

})

//Admin:get specific user
exports.getspecificuser = Catch(async (req, res, next) => {
    const user = await userDeatils.findById(req.user.id)
    if (!user) {
        return next(new ErrorHandler('user not found', 401))
    }
    res.status(200).json({
        success: true,
        user
    })
})

//Admin:Upadte user
exports.getUpadteuser = Catch(async (req, res, next) => {
    const uopdateuser = {
        name: req.body.name,
        email: req.body.email,
        roole: req.body.roole
    }

    const user = await userDeatils.findByIdAndUpdate(req.user.id, uopdateuser, {
        new: true,
        runValidators: true
    })
    res.status(200).json({
        success: true,
        user
    })

})

//Admin:Delete User
exports.Deleteuser = Catch(async (req, res, next) => {
    const user = await userDeatils.findById(req.user.id)
    if (!user) {
        return next(new ErrorHandler('user not found'))

    }
    await userDeatils.deleteOne({ _id: user.id })
    res.status(200).json({
        success: true,
        message: "User Details Remove"
    })
})



