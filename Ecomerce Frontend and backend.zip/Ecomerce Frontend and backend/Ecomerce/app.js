const express=require('express')
const app = express();
const product=require('./routes/product')
const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(express.json());
const dotenv=require('dotenv')
const path=require('path')
const errorMiddleware = require('./middlewere/error');
const userDetails=require('./routes/userroute')
const OderDetails=require("./routes/oderroute")
const cookieParser = require('cookie-parser');
const payment = require('./routes/paymentdata');
dotenv.config({path:path.join(__dirname,"confi/confi.env")})


app.use(cookieParser())
app.use('/api/v1',product)
app.use('/api/v1',userDetails)
app.use('/api/v1',OderDetails)
app.use('/api/v1',payment)
app.use(errorMiddleware);
module.exports=app;