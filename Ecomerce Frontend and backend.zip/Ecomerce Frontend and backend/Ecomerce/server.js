const app=require('./app')

const connectdatabase=require('./confi/databse')

connectdatabase()
//Port Runing functon

const server=app.listen(process.env.PORT,()=>{
    console.log('server connect');
})

process.on('unhandledRejection', (err) => {
    console.log(`Error: ${err.message}`);
    console.log('Shutting down the server due to Unhandled Promise Rejection');
    server.close(() => {
        process.exit(1);
    });
});
process.on('uncaughtException', (err) => {
    console.log(`Error: ${err.message}`);
    console.log('Shutting down the server due to Uncaught Exception');
    server.close(() => {
        process.exit(1);
    });
});