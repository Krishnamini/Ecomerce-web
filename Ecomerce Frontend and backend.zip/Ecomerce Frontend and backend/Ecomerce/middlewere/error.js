// middlewares/error.js
// module.exports = (err, req, res, next) => {
//     err.statusCode = err.statusCode || 500;

//     if (process.env.NODE_ENV === 'development') {
//         res.status(err.statusCode).json({
//             success: false,
//             error: err,
//             message: err.message,
//             stack: err.stack
//         });
//     } else if (process.env.NODE_ENV === 'production') {
//         let message = err.message;

//         // Generic message for production if needed
//         if (!err.isOperational) {
//             message = 'Something went wrong!';
//         }

//         res.status(err.statusCode).json({
//             success: false,
//             message: message
//         });
//     }
// };
module.exports = (err, req, res, next) => {
    err.statusCode = err.statusCode || 500
    let message = err.message
    let error={...err}
    if (err.name==='CastError') {
        message=`resoure not ${err.path}`
        error=new Error(message)
    }
    res.status(err.statusCode).json({
        success: false,
        error: err,
        message: err.message,
        stack: err.stack

    })
} 
