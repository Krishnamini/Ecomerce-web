const Catch = require('../middlewere/catch')
const ErrorHandler = require('../utils/ErrorHandle')
const jwt = require('jsonwebtoken')
const modal = require('../modalcreate/usermodal')

//user login to product details show cookies
exports.UserAuth = Catch(async (req, res, next) => {
    const { token } = req.cookies
    if (!token) {
        return next(new ErrorHandler('Login first to handle this resoures'))
    }
    // Decode the token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await modal.findById(decoded.id);

    // Check if user exists
    if (!user) {
        return next(new ErrorHandler('User not found', 404));
    }
    req.user = user;
    console.log(req.user.id)

    next();


})
exports.AuthuserRole = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.roole)) {
            return next(new ErrorHandler(`role ${req.user.roole} is not allowed`));
        }
        next();
    };
}
