const sendToken = (user, statusCode, res) => {
    const token = user.getJwtToken()
    //setting cookies
   
    res.status(statusCode).json({
        sucess: true,
        token,
        user
    })
}
module.exports=sendToken