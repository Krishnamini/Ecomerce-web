
const products=require('../data/product.json')
const product =require('../modalcreate/productmodal')
const dotenv = require('dotenv');
const connection=require('../confi/databse')
dotenv.config({path:"Ecomerce/confi/confi.env"});

connection()
const seeder=async(res,req,next)=>{
    try{
        await product.deleteMany()
        console.log('Products deleted successfully');
        await product.insertMany(products)
        console.log('Products inserted successfully');
        // process.exit()
    }catch (error) {
        console.error('Error inserting products', error);
        process.exit(1);
    }

}
seeder()