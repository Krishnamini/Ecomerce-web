const express = require('express');
const { newoder, GetsingleOrder, GetLoginuserOrders, GetallusersOrder, UpdateOrders, Deleted } = require('../controllers/Odercreated');
const { UserAuth, AuthuserRole } = require('../middlewere/authication');


const router = express.Router()

router.route("/order/new").post(UserAuth, newoder)
router.route("/order/:id").get(UserAuth, GetsingleOrder)
router.route("/myorders").get(UserAuth,GetLoginuserOrders)
//Admin Rotues
router.route("/allorders").get(UserAuth,AuthuserRole('admin'),GetallusersOrder)
router.route("/allorders/:id").put(UserAuth,AuthuserRole('admin'),UpdateOrders)
router.route("/Deleted/:id").delete(UserAuth,AuthuserRole('admin'),Deleted)



module.exports = router