const express = require('express');
const router = express.Router();
const { createRazorpayOrder } = require('../controllers/Payment'); // Adjust the path as needed
const { UserAuth } = require('../middlewere/authication');

router.post('/payment/process',UserAuth, createRazorpayOrder);

module.exports = router;
