const express = require('express')
const { UserRigester, userDeatilsId, UserLogin, userlogout, forgot, getuser,changepassword, userUpdate, Deleteuser, getUpadteuser, getspecificuser, getalluser} = require('../controllers/Usercontroller')
const { UserAuth, AuthuserRole } = require('../middlewere/authication')
const route=express.Router()

route.route('/usercraete').post(UserRigester)
route.route('/usercraete/:id').get(userDeatilsId)
route.route('/userlogin').post(UserLogin)
route.route('/userlogout').get(userlogout)
route.route('/password/resetpass').post(forgot)
route.route('/myprofile').get(UserAuth,getuser)
route.route('/Changepassword').put(UserAuth,changepassword)
route.route('/userUpdate').put(UserAuth,userUpdate)

//Admin
route.route('/admin/user').get(UserAuth,AuthuserRole('admin'),getalluser)
route.route('/admin/user/:id').get(UserAuth,AuthuserRole('admin'),getspecificuser)
route.route('/admin/userUpdate').put(UserAuth,AuthuserRole('admin'),getUpadteuser)
route.route('/admin/userDelete').delete(UserAuth,AuthuserRole('admin'),Deleteuser)

module.exports = route;
