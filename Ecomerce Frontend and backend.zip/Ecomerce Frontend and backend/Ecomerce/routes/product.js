const express = require('express');

const { getproduct, newproduct, getsingleId, updatedata, deleteProduct, userRiewesCreate, userRiewesFind, userReviewsDeleted } = require('../controllers/productcontroler');
const { UserAuth, AuthuserRole } = require('../middlewere/authication');


const router = express.Router();

router.route('/product').get(getproduct);

router.route('/product/:id').get(getsingleId)
router.route('/updateproduct/:id').put(updatedata).delete(deleteProduct)

//admin
router.route('/product/new').post(UserAuth,AuthuserRole('admin'),newproduct);

//product Riwes
router.route('/product/reviewscreate').put(UserAuth,userRiewesCreate);

router.route('/reviewsfind').get(userRiewesFind)

router.route('/reviewDelete').delete(userReviewsDeleted)


module.exports = router;